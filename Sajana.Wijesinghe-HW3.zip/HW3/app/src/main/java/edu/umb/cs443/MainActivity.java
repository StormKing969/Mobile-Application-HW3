package edu.umb.cs443;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainActivity extends FragmentActivity implements OnMapReadyCallback{

	public final static String DEBUG_TAG="edu.umb.cs443.MYMSG";
	private TextView result;
	private EditText input;
	private Button submit;
	private String query;
	private ImageView display;
    private GoogleMap mMap;
    private double lon;
    private double lat;
    private double temp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setup();

        MapFragment mFragment=((MapFragment) getFragmentManager().findFragmentById(R.id.map));
        mFragment.getMapAsync(this);
        getWeatherInfo();
    }

    public String LocationQuery(String locationUrl) {
        if(locationUrl.matches("[0-9]+")) {
            return query = "http://api.openweathermap.org/data/2.5/weather?zip="+locationUrl+"&APPID=cc4ae6e545dee0a295a471824c9fdbda";
        }
        else{
            return query = "http://api.openweathermap.org/data/2.5/weather?q="+locationUrl+"&APPID=cc4ae6e545dee0a295a471824c9fdbda";
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setup() {
        result =  findViewById(R.id.textView);
        input = findViewById(R.id.editText);
        submit = findViewById(R.id.button);
        display = findViewById(R.id.imageView);
    }

    public void getWeatherInfo(){
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        String weather = input.getText().toString();
                        try {
                            String coordinate = LocationQuery(weather);
                            setWeather(coordinate);
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }

    public void setWeather(String coordinates) {
        InputStream stream = null;
        String output;
        try {
            URL url = new URL(coordinates);
            HttpURLConnection request = (HttpURLConnection) url.openConnection();
            request.connect();

            stream = request.getInputStream();
            output = load(stream, 1500);

            JSONObject js = new JSONObject(output);
            lon = js.getJSONObject("coord").getDouble("lon");
            lat = js.getJSONObject("coord").getDouble("lat");
            temp = js.getJSONObject("main").getDouble("temp");

            String Temperature = String.valueOf((int) (temp * 9/5-459.67));

            //Gets the file path for the png file
            JSONArray array = js.getJSONArray("weather");
            String link = array.getJSONObject(0).getString("icon");

            image(link);

            try {
                CreateMAP(lat, lon);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            result.setText(Temperature + "F");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void CreateMAP(double lat, double lon) {
        final double latitude = lat;
        final double longitude = lon;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 11));
            }
        });
    }

    public void image(String link) {
        InputStream PNG = null;

        try {
            URL imglink = new URL("http://openweathermap.org/img/w/" + link + ".png");
            HttpURLConnection request = (HttpURLConnection)imglink.openConnection();
            request.connect();

            PNG = request.getInputStream();
            Bitmap M = BitmapFactory.decodeStream(PNG);

            Drawable draw = new BitmapDrawable(getResources(), M);
            display.setBackground(draw);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(GoogleMap map) {
        this.mMap=map;
    }

    private String load(InputStream stream, int max) throws IOException {
        String Output = null;
        InputStreamReader reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[max];
        int num = 0;
        int size = 0;
        while (num < max && size != -1) {
            num = num + size;
            int i = (100 * num) / max;
            size = reader.read(buffer, num, buffer.length - num);
        }
        if(num != -1) {
            num = Math.min(num, max);
            Output = new String(buffer, 0, num);
        }
        return Output;
    }
}
